<h1  {{  $attributes(['class' => 'font-bold text-center text-3xl mb-3 mt-3 uppercase']) }}> {{ $slot }} </h1>
