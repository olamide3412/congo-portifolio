<div>
    <div class="bg-black/10 my-10 h-px w-full"></div>
</div>
