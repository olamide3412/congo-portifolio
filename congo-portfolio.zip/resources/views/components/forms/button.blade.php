<button {{ $attributes(['class' => 'bg-secondary-500 hover:bg-secondary-700 rounded py-2 px-6 font-bold text-white']) }}>{{ $slot }}</button>
