<h4 {{  $attributes(['class' => 'text-md font-bold py-1 text-primary cursor-pointer  hover:text-xl w-full mt-4 mb-2 uppercase']) }}>
    {{ $slot }}
</h4>
