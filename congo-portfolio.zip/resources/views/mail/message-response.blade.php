<x-mail::message>
# Response

Dear {{ $mesage->name }},
This is to inform you that the {{$updateType}} for **{{ $courseComponet->course->course_title_code }} {{ $courseComponet->component }}** has been updated.
Your message with ticket id {{ $mesage->ticket_number }} was received successfully and will be responded to shortly.

<x-mail::button :url="''">
Button Text
</x-mail::button>

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
