<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dieu est bon et riche'); ?></title>
    <link rel="icon" type="image/png" href="<?php echo e(Vite::asset('resources/images/dbr.png')); ?>">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


 <!-- Important: vite import -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
 <!-- Important: vite import -->

</head>
<body >



    <div class="bg-gray-100 flex flex-col min-h-screen" >
        <?php if (isset($component)) { $__componentOriginala591787d01fe92c5706972626cdf7231 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala591787d01fe92c5706972626cdf7231 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $attributes = $__attributesOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__attributesOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $component = $__componentOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__componentOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>

        <!-- Main Content -->
        <main class="flex-grow space-y-0 ">
            <?php echo e($slot); ?>

        </main>

        <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
    </div>
    <button id="scrollTopBtn" class="fixed bottom-5 right-5 bg-secondary-300 text-white p-3 rounded-full shadow-lg hidden transition-opacity duration-500">
        ↑
    </button>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const scrollTopBtn = document.getElementById("scrollTopBtn");

            // When the user scrolls down 100px from the top of the document, show the button
            window.onscroll = function() {
                if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
                    scrollTopBtn.classList.remove('hidden');
                    scrollTopBtn.classList.add('opacity-100');
                } else {
                    scrollTopBtn.classList.add('hidden');
                    scrollTopBtn.classList.remove('opacity-100');
                }
            };

            // When the user clicks on the button, scroll to the top of the document
            scrollTopBtn.addEventListener('click', function () {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });

           // toastr.success('HII');
            <?php if(session('success')): ?>
                 toastr.success('<?php echo e(session('success')); ?>');
            <?php endif; ?>


            <?php if(Session::has('message')): ?>
                toastr.success("<?php echo e(session('message')); ?>");
            <?php endif; ?>

            <?php if(Session::has('error')): ?>
                toastr.error("<?php echo e(session('error')); ?>");
            <?php endif; ?>

            <?php if(Session::has('info')): ?>
                toastr.info("<?php echo e(session('info')); ?>");
            <?php endif; ?>

            <?php if(Session::has('warning')): ?>
                toastr.warning("<?php echo e(session('warning')); ?>");
            <?php endif; ?>

        });

    </script>

</body>
</html>
<?php /**PATH C:\lara\congo-portfolio\resources\views/components/layout.blade.php ENDPATH**/ ?>