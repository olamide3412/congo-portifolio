<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <section class="text-center pt-6 mb-10  ">
        <h1 class="font-bold text-4xl uppercase mb-5"><?php echo app('translator')->get('messages.messages'); ?></h1>
        <?php if (isset($component)) { $__componentOriginala22641835cdc236e966401327a423643 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala22641835cdc236e966401327a423643 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.form','data' => ['action' => ''.e(route('message.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('message.index')).'']); ?>
        <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['label' => false,'value' => ''.e(request('q','')).'','name' => 'q','placeholder' => ''.e(__('messages.search_message_text')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'value' => ''.e(request('q','')).'','name' => 'q','placeholder' => ''.e(__('messages.search_message_text')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala22641835cdc236e966401327a423643)): ?>
<?php $attributes = $__attributesOriginala22641835cdc236e966401327a423643; ?>
<?php unset($__attributesOriginala22641835cdc236e966401327a423643); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala22641835cdc236e966401327a423643)): ?>
<?php $component = $__componentOriginala22641835cdc236e966401327a423643; ?>
<?php unset($__componentOriginala22641835cdc236e966401327a423643); ?>
<?php endif; ?>
    </section>


    <div class="space-y-2 md:px-10">


        <div class="hidden md:block overflow-x-auto">
            <div class="min-w-fit">
                <table class="min-w-fit bg-white border">
                    <thead>
                        <tr class="text-left bg-secondary-500 text-white">
                            <th class="py-2 px-4 border">SN</th>
                            <th class="py-2 px-4 border"><?php echo app('translator')->get('messages.ticket'); ?></th>
                            <th class="py-2 px-4 border"><?php echo app('translator')->get('messages.msg_form_name'); ?></th>
                            <th class="py-2 px-4 border">Email</th>
                            <th class="py-2 px-4 border"><?php echo app('translator')->get('messages.msg_form_message'); ?></th>
                            <th class="py-2 px-4 border"><?php echo app('translator')->get('messages.time'); ?></th>
                            <th class="py-2 px-4 border"><?php echo app('translator')->get('messages.action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-100">
                                <td class="py-2 px-4 border"><?php echo e(($messages->currentPage() - 1) * $messages->perPage() + $loop->index + 1); ?></td>
                                <td class="py-2 px-4 border"><?php echo e($message->ticket_number); ?></td>
                                <td class="py-2 px-4 border"><?php echo e($message->name); ?></td>
                                <td class="py-2 px-4 border"><?php echo e($message->email); ?></td>
                                <td class="py-2 px-4 border"><?php echo e($message->message); ?></td>
                                <td class="py-2 px-4 border text-nowrap"><?php echo e(get_date_time_interval($message->created_at)); ?></td>
                                <td class="py-2 px-4 border">
                                    <a href="<?php echo e(route('message.show', $message)); ?>" class="text-secondary-500 hover:text-secondary-700"><?php echo app('translator')->get('messages.view'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="py-10">
                    <?php echo e($messages->links()); ?>

                </div>
            </div>
        </div>

        <div class="block md:hidden p-5">
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white border rounded-lg mb-4 p-4 shadow-lg">

                <div class="mb-2">
                    <span class="font-bold"><?php echo app('translator')->get('messages.ticket_number'); ?>:</span>
                    <span><?php echo e($message->ticket_number); ?></span>
                </div>

                <div class="mb-2">
                    <span class="font-bold"><?php echo app('translator')->get('messages.msg_form_message'); ?>:</span>
                    <p class="text-justify">
                        <?php echo e(Str::limit($message->message, 100, '...')); ?>

                        <a href="<?php echo e(route('message.show', $message)); ?>" class="text-secondary-400 hover:text-secondary-700 "><?php echo app('translator')->get('messages.view'); ?></a>
                    </p>
                </div>
                <div class="mb-2">
                    <span class="font-bold"><i class="fa-solid fa-user"></i></span>
                    <span><?php echo e($message->name); ?></span>
                </div>
                <div class="mb-2">
                    <span class="font-bold"><i class="fa-solid fa-at"></i></span>
                    <span><?php echo e($message->email); ?></span>
                </div>
                <div class="mb-2 flex justify-end">
                    <span><?php echo e(get_date_time_interval($message->created_at)); ?></span>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="py-10">
                <?php echo e($messages->links()); ?>

            </div>
        </div>




    </div>











 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\lara\congo-portfolio\resources\views/users/message/index.blade.php ENDPATH**/ ?>