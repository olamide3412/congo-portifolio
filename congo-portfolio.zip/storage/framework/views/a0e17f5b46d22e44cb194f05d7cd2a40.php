<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>




     <!-- About Section -->
     <div id="about" class=" grid grid-cols-1 md:grid-cols-1 py-28  text-center  group bg-secondary-500 text-white space-y-5 ">
       <div class="space-y-5 px-10">
            <h2 class="text-4xl font-bold  hover:animate-bounce"><?php echo app('translator')->get('messages.about'); ?></h2>
            <p class="text-lg leading-relaxed max-w-3xl mx-auto text-justify">
                <?php echo app('translator')->get('messages.about_statement'); ?>
            </p>
       </div>
        <div class=" hidden p-1  border border-transparent hover:border-secondary-200  md:w-1/2   mx-auto">
            <iframe width="100%" height="315" src="https://www.youtube.com/embed/-EoNrg_DR3s?si=FhG2tH47DeY6ygeL" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </div>

    </div>

    <!-- Features Section -->
    <div id="service" class="container grid grid-cols-1 md:grid-cols-2 mx-auto py-10 px-6    group">
        <div class=" flex items-center md:justify-items-end">
            <h2 class="text-4xl font-bold text-secondary-400  text-left mb-10 group-hover:animate-bounce"><?php echo app('translator')->get('messages.our_value'); ?></h2>
        </div>

        <div class="grid grid-cols-1  gap-8 text-justify">

              <div class="collapsible-section border-b-2 border-gray-300 p-4">
                <h2 class="toggle-header flex items-center cursor-pointer text-lg font-semibold text-gray-800">
                  <span class="arrow mr-2 transition-transform transform rotate-0">▶</span> <?php echo app('translator')->get('messages.our_value_1'); ?>
                </h2>
                <div class="toggle-content max-h-0 overflow-hidden transition-all duration-500 ease-in-out">
                  <p class="text-gray-600 mt-4 ">
                   <?php echo app('translator')->get('messages.our_value_1_text'); ?>
                  </p>
                </div>
              </div>

              <div class="collapsible-section border-b-2 border-gray-300 p-4">
                <h2 class="toggle-header flex items-center cursor-pointer text-lg font-semibold text-gray-800">
                  <span class="arrow mr-2 transition-transform transform rotate-0">▶</span> <?php echo app('translator')->get('messages.our_value_2'); ?>
                </h2>
                <div class="toggle-content max-h-0 overflow-hidden transition-all duration-500 ease-in-out">
                  <p class="text-gray-600 mt-4">
                    <?php echo app('translator')->get('messages.our_value_2_text'); ?>
                  </p>
                </div>
              </div>

              <div class="collapsible-section border-b-2 border-gray-300 p-4">
                <h2 class="toggle-header flex items-center cursor-pointer text-lg font-semibold text-gray-800">
                    <span class="arrow mr-2 transition-transform transform rotate-0 bg-transparent focus:bg-transparent focus:outline-none">▶</span>
                    <?php echo app('translator')->get('messages.our_value_3'); ?>
                </h2>
                <div class="toggle-content max-h-0 overflow-hidden transition-all duration-500 ease-in-out">
                  <p class="text-gray-600 mt-4">
                    <?php echo app('translator')->get('messages.our_value_3_text'); ?>
                  </p>
                </div>
              </div>




        </div>
    </div>


    <div  class=" container grid grid-cols-1 md:grid-cols-2 p-10  space-y-5 text-justify">
        <div class=" flex items-center md:justify-items-end">
            <h2 class="text-4xl font-bold text-secondary-400"><?php echo app('translator')->get('messages.why_choose_us'); ?></h2>
        </div>
        <div class=" flex items-center md:justify-items-end">
            <p class="text-lg leading-relaxed max-w-3xl mx-auto">
                <?php echo app('translator')->get('messages.why_choose_us_text'); ?>
            </p>
        </div>


    </div>

    <div class="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 justify-items-center gap-8 p-5">
        <?php if (isset($component)) { $__componentOriginal73c55255cb78153772fa1be56dcb0ead = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73c55255cb78153772fa1be56dcb0ead = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.staff-view','data' => ['position' => 'CEO','name' => 'Mr. Ugochukwu Solomon Njideofor','image' => Vite::asset('resources/images/ceo_img.png')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('staff-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['position' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('CEO'),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Mr. Ugochukwu Solomon Njideofor'),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(Vite::asset('resources/images/ceo_img.png'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73c55255cb78153772fa1be56dcb0ead)): ?>
<?php $attributes = $__attributesOriginal73c55255cb78153772fa1be56dcb0ead; ?>
<?php unset($__attributesOriginal73c55255cb78153772fa1be56dcb0ead); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73c55255cb78153772fa1be56dcb0ead)): ?>
<?php $component = $__componentOriginal73c55255cb78153772fa1be56dcb0ead; ?>
<?php unset($__componentOriginal73c55255cb78153772fa1be56dcb0ead); ?>
<?php endif; ?>
    </div>







    <script>
        document.addEventListener('DOMContentLoaded', function () {


            document.querySelectorAll('.collapsible-section').forEach(section => {
                const toggleHeader = section.querySelector('.toggle-header');
                const toggleContent = section.querySelector('.toggle-content');
                const arrow = section.querySelector('.arrow');

                toggleHeader.addEventListener('click', () => {
                    if (toggleContent.classList.contains('max-h-0')) {
                        toggleContent.classList.remove('max-h-0');
                        toggleContent.classList.add('max-h-40'); // Adjust height as needed
                        arrow.classList.add('rotate-90');
                    } else {
                        toggleContent.classList.remove('max-h-40');
                        toggleContent.classList.add('max-h-0');
                        arrow.classList.remove('rotate-90');
                    }
                });
            });






       });
    </script>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\lara\congo-portfolio\resources\views/about.blade.php ENDPATH**/ ?>