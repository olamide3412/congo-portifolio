<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <div class="container mx-auto sm:px-6 lg:px-8 py-12 px-5">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
            <div class="flex items-center">
                <div>
                    <h1 class="text-xl font-semibold"><strong><?php echo app('translator')->get('messages.ticket_number'); ?>: </strong><?php echo e($message->ticket_number); ?></h1>
                    <p class="text-gray-600 font-semibold">E-mail: <?php echo e($message->email); ?></p>
                </div>
            </div>
            <p class=" text-end"><?php echo e(get_date_time_interval($message->created_at)); ?></p>
        </div>

        <div class="container mx-auto py-3">
                <h3 class="text-2xl font-bold mb-3"><?php echo app('translator')->get('messages.msg_form_message'); ?></h3>
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <p class=" mb-5 text-justify"> <?php echo e($message->message); ?></p>
                    <p><strong>Locale:</strong> <?php echo e($message->locale); ?></p>
                    <p><strong><?php echo app('translator')->get('messages.last_date_updated'); ?>: </strong> <?php echo e(get_date_specific_format($message->updated_at, 'D, d-M-Y h:i')); ?></p>


                    <a href="<?php echo e(route('message.index')); ?>" class="text-blue-500 hover:text-blue-700 mt-4 inline-block"><?php echo app('translator')->get('messages.back_to_messages'); ?></a>
                    <p class="inline text-bold"> | </p>
                     <!-- Custom Delete Button -->
                     <button onclick="confirmDelete()" class="text-red-500 hover:text-red-700 ml-2"><?php echo app('translator')->get('messages.delete'); ?></button>


                </div>
        </div>


   </div>


</div>


    <?php if (isset($component)) { $__componentOriginal2b3245a5746dec4123f46f887cebc745 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b3245a5746dec4123f46f887cebc745 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.delete','data' => ['key' => ''.e($message->id).'','route' => 'message.destroy','message' => ''.e(__('messages.delete_prompt_message')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['key' => ''.e($message->id).'','route' => 'message.destroy','message' => ''.e(__('messages.delete_prompt_message')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b3245a5746dec4123f46f887cebc745)): ?>
<?php $attributes = $__attributesOriginal2b3245a5746dec4123f46f887cebc745; ?>
<?php unset($__attributesOriginal2b3245a5746dec4123f46f887cebc745); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b3245a5746dec4123f46f887cebc745)): ?>
<?php $component = $__componentOriginal2b3245a5746dec4123f46f887cebc745; ?>
<?php unset($__componentOriginal2b3245a5746dec4123f46f887cebc745); ?>
<?php endif; ?>




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\lara\congo-portfolio\resources\views/users/message/show.blade.php ENDPATH**/ ?>