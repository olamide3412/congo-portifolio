<?php
    $nav_class = ' py-2 px-2 text-gray-900  font-semibold hover:text-secondary-500';
    $nav_class_moblie = ' block px-3 py-2 rounded-md text-base font-medium hover:bg-secondary-500 hover:text-white';
?>
<nav x-data="{ open: false }" class="flex justify-between items-center py-2 border-b border-white/10 p-3 bg-white shadow-md fixed top-0 left-0 w-full z-50">
    <div :class="{ 'hidden': open }">
        <a href="/">
            <img src="<?php echo e(Vite::asset('resources/images/dbr.png')); ?>" width="40" height="25" alt="" class=" inline">
            <span class=" font-semibold text-gray-500 text-lg">Dieu est bon et riche</span>
        </a>
    </div>
    <!-- Primary Navbar items -->
    <div class="hidden md:flex items-center space-x-1">
        <a href="/" class=" py-2 px-2 text-gray-900  font-semibold rounded-sm " > <?php echo app('translator')->get('messages.home'); ?> </a>
        <a href="<?php echo e(route('about')); ?>" class="<?php echo e($nav_class); ?>"><?php echo app('translator')->get('messages.about_us'); ?></a>
        <a href="<?php echo e(route('service')); ?>" class="<?php echo e($nav_class); ?>"><?php echo app('translator')->get('messages.services'); ?></a>
        <a href="<?php echo e(route('contact')); ?>" class="<?php echo e($nav_class); ?>"><?php echo app('translator')->get('messages.contact_us'); ?></a>
        <?php if(auth()->guard()->check()): ?>

             <div x-data="{ open: false }" class="relative">
                <a href="#" @click.prevent="open = !open" class="cursor-pointer <?php echo e($nav_class); ?>"><?php echo app('translator')->get('messages.main_menu'); ?></a>
                <div x-show="open" @click.away="open = false" x-transition class="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-lg">
                    <a href="<?php echo e(route('dashboard.users')); ?>" class="<?php echo e($nav_class_moblie); ?>"><?php echo app('translator')->get('messages.dashboard'); ?></a>
                    <a href="<?php echo e(route('message.index')); ?>" class="<?php echo e($nav_class_moblie); ?>"><?php echo app('translator')->get('messages.messages'); ?></a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="flex items-center space-x-2">

        <div class="hidden md:flex">
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" @click="open = false" class="px-3 py-2 rounded-md text-base font-medium hover:bg-secondary-500 hover:text-white">Login</a>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                <div class="px-3 py-2 rounded-md text-base font-medium hover:bg-red-500 hover:text-white">
                    <?php if (isset($component)) { $__componentOriginalf555c4677f26ce176bcf8bc84da6231e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf555c4677f26ce176bcf8bc84da6231e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf555c4677f26ce176bcf8bc84da6231e)): ?>
<?php $attributes = $__attributesOriginalf555c4677f26ce176bcf8bc84da6231e; ?>
<?php unset($__attributesOriginalf555c4677f26ce176bcf8bc84da6231e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf555c4677f26ce176bcf8bc84da6231e)): ?>
<?php $component = $__componentOriginalf555c4677f26ce176bcf8bc84da6231e; ?>
<?php unset($__componentOriginalf555c4677f26ce176bcf8bc84da6231e); ?>
<?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php if (isset($component)) { $__componentOriginalb87830766b71837deaf009e60ac1da08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb87830766b71837deaf009e60ac1da08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lang','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lang'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb87830766b71837deaf009e60ac1da08)): ?>
<?php $attributes = $__attributesOriginalb87830766b71837deaf009e60ac1da08; ?>
<?php unset($__attributesOriginalb87830766b71837deaf009e60ac1da08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb87830766b71837deaf009e60ac1da08)): ?>
<?php $component = $__componentOriginalb87830766b71837deaf009e60ac1da08; ?>
<?php unset($__componentOriginalb87830766b71837deaf009e60ac1da08); ?>
<?php endif; ?>
    </div>



<!-- Container element with x-data -->
<div x-data="{ open: false }" class=" md:hidden">
    <!-- Toggle Button for Mobile Menu -->
    <button @click="open = !open" class="text-secondary-500 focus:outline-none" :aria-expanded="open ? 'true' : 'false'" aria-controls="mobile-menu" type="button">
        <!-- SVG icons here -->
        <svg :class="open ? 'hidden' : 'block'" class="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" />
        </svg>
        <svg :class="open ? 'block' : 'hidden'" class="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
        </svg>
    </button>

    <!-- Mobile Menu -->
    <div x-show="open" @click.away="open = false" class="absolute top-14 right-0 w-48 bg-white shadow-lg rounded-lg p-4 z-50" id="mobile-menu" x-transition>
        <!-- Menu items here -->
        <div class="space-y-2">
            <!-- Menu Links that close the menu when clicked -->
            <a href="/" @click="open = false" class="<?php echo e($nav_class_moblie); ?>"><?php echo app('translator')->get('messages.home'); ?></a>
            <a href="<?php echo e(route('about')); ?>" @click="open = false" class="<?php echo e($nav_class_moblie); ?>"><?php echo app('translator')->get('messages.about_us'); ?></a>
            <a href="<?php echo e(route('service')); ?>" @click="open = false" class="<?php echo e($nav_class_moblie); ?>"><?php echo app('translator')->get('messages.services'); ?></a>
            <a href="<?php echo e(route('contact')); ?>" @click="open = false" class="<?php echo e($nav_class_moblie); ?>"><?php echo app('translator')->get('messages.contact_us'); ?></a>
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" @click="open = false" class="<?php echo e($nav_class_moblie); ?>">Login</a>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <div x-data="{ open: false }" class="relative">
                    <a href="#" @click.prevent="open = !open" class="cursor-pointer <?php echo e($nav_class); ?>"><?php echo app('translator')->get('messages.main_menu'); ?></a>
                    <div x-show="open" @click.away="open = false" x-transition class="absolute  right-1/2 mt-2 mr-20  w-36 bg-white shadow-lg rounded-lg">
                        <a href="<?php echo e(route('dashboard.users')); ?>" class="<?php echo e($nav_class_moblie); ?>"><?php echo app('translator')->get('messages.dashboard'); ?></a>
                        <a href="<?php echo e(route('message.index')); ?>" class="<?php echo e($nav_class_moblie); ?>"><?php echo app('translator')->get('messages.messages'); ?></a>
                    </div>
                </div>

                <div class="px-3 py-2 rounded-md text-base font-medium hover:bg-red-500 hover:text-white">
                    <?php if (isset($component)) { $__componentOriginalf555c4677f26ce176bcf8bc84da6231e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf555c4677f26ce176bcf8bc84da6231e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf555c4677f26ce176bcf8bc84da6231e)): ?>
<?php $attributes = $__attributesOriginalf555c4677f26ce176bcf8bc84da6231e; ?>
<?php unset($__attributesOriginalf555c4677f26ce176bcf8bc84da6231e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf555c4677f26ce176bcf8bc84da6231e)): ?>
<?php $component = $__componentOriginalf555c4677f26ce176bcf8bc84da6231e; ?>
<?php unset($__componentOriginalf555c4677f26ce176bcf8bc84da6231e); ?>
<?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

</nav>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        // Helper function to handle scrolling or redirection

        function handleNavigation(linkSelector, sectionId) {
            const link = document.querySelector(linkSelector);
            const section = document.getElementById(sectionId);
            const navBarHeight = document.querySelector('nav').offsetHeight; // Get the height of the navigation bar

            if (link && section) {
                link.addEventListener('click', function (e) {
                    e.preventDefault();

                    if (window.location.pathname === '/') {
                        // If on the landing page, scroll to the section
                        window.scrollTo({
                            top: section.offsetTop - navBarHeight, // Offset by the height of the navbar
                            behavior: 'smooth'
                        });
                    } else {
                        // If not on the landing page, navigate to the landing page and scroll to the section
                        window.location.href = `/#${sectionId}`;
                    }
                });
            }
        }

         // Handle navigation desktop
        handleNavigation('a[href="#home-desktop"]', 'home');
        handleNavigation('a[href="#about-desktop"]', 'about');
        handleNavigation('a[href="#service-desktop"]', 'service');
        handleNavigation('a[href="#contact-desktop"]', 'contact');

        // Handle navigation for mobile
        handleNavigation('a[href="#home-mobile"]', 'home');
        handleNavigation('a[href="#about-mobile"]', 'about');
        handleNavigation('a[href="#service-mobile"]', 'service');
        handleNavigation('a[href="#contact-mobile"]', 'contact');




        const navItems = document.querySelectorAll('.nav-item');

        navItems.forEach(item => {
            item.addEventListener('click', function(event) {
                event.preventDefault(); // Prevent default link behavior for demonstration

                // Remove the active class from all items
                //navItems.forEach(nav => nav.classList.remove('border-b-4', 'border-secondary-500'));

                // Add the active class to the clicked item
                this.classList.add('border-b-4', 'border-secondary-500');
            });
        });







    });
</script>

<?php /**PATH C:\lara\congo-portfolio\resources\views/components/navbar.blade.php ENDPATH**/ ?>