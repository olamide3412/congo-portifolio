<div>
    <div class="bg-black/10 my-10 h-px w-full"></div>
</div>
<?php /**PATH C:\lara\congo-portfolio\resources\views/components/forms/divider.blade.php ENDPATH**/ ?>