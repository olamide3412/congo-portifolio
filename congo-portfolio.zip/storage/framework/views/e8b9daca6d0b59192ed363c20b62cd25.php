<form method="POST" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button><?php echo app('translator')->get('messages.logout'); ?></button>
</form>
<?php /**PATH C:\lara\congo-portfolio\resources\views/components/logout.blade.php ENDPATH**/ ?>