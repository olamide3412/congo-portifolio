<div id="service" class="container mx-auto py-10 px-6  rounded-lg  group">
    <?php
        $each_service_div_class = 'bg-white p-6 rounded-lg shadow-md transition-transform duration-500 hover:scale-105 hover:shadow-xl';
    ?>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 ">

        <?php
            $s_h3_style = 'text-2xl font-semibold mb-4';
        ?>
        <div class="<?php echo e($each_service_div_class); ?>">
            <h3 class="<?php echo e($s_h3_style); ?>"><?php echo app('translator')->get('messages.electronic_money_transfer'); ?></h3>
            <p class="text-gray-600 text-justify"><?php echo app('translator')->get('messages.electronic_money_transfer_text'); ?> </p>
        </div>

        <div class="<?php echo e($each_service_div_class); ?>">
            <h3 class="<?php echo e($s_h3_style); ?>"><?php echo app('translator')->get('messages.western_union_transfer'); ?></h3>
            <p class="text-gray-600 text-justify"><?php echo app('translator')->get('messages.western_union_transfer_text'); ?></p>
        </div>
        <div class="<?php echo e($each_service_div_class); ?>">
            <h3 class="<?php echo e($s_h3_style); ?>"><?php echo app('translator')->get('messages.exchange_to_dollar'); ?></h3>
            <p class="text-gray-600 text-justify"><?php echo app('translator')->get('messages.exchange_to_dollar_text'); ?></p>
        </div>

        <div class="<?php echo e($each_service_div_class); ?>">
            <h3 class="<?php echo e($s_h3_style); ?>"><?php echo app('translator')->get('messages.cash_express_locally'); ?></h3>
            <p class="text-gray-600 text-justify"><?php echo app('translator')->get('messages.cash_express_locally_text'); ?></p>
        </div>

        <div class="<?php echo e($each_service_div_class); ?>">
            <h3 class="<?php echo e($s_h3_style); ?>"><?php echo app('translator')->get('messages.fin_tech_consulting'); ?></h3>
            <p class="text-gray-600 text-justify"><?php echo app('translator')->get('messages.fin_tech_consulting_text'); ?></p>
        </div>

        <div class="<?php echo e($each_service_div_class); ?>">
            <h3 class="<?php echo e($s_h3_style); ?>"><?php echo app('translator')->get('messages.ai_driven_fin_analytics'); ?></h3>
            <p class="text-gray-600 text-justify"><?php echo app('translator')->get('messages.ai_driven_fin_analytics_text'); ?></p>
        </div>

    </div>
</div>
<?php /**PATH C:\lara\congo-portfolio\resources\views/include/service.blade.php ENDPATH**/ ?>