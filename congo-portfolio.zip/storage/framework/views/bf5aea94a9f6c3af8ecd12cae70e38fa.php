<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container mx-auto p-1">
        <div class="text-left">
            <?php if (isset($component)) { $__componentOriginal4de142f7baa3ebde9816de5235a7814f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4de142f7baa3ebde9816de5235a7814f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-location','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-location'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo e(Auth::user()->user_type); ?>><?php echo e(Auth::user()->first_name); ?>>dashboard   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4de142f7baa3ebde9816de5235a7814f)): ?>
<?php $attributes = $__attributesOriginal4de142f7baa3ebde9816de5235a7814f; ?>
<?php unset($__attributesOriginal4de142f7baa3ebde9816de5235a7814f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4de142f7baa3ebde9816de5235a7814f)): ?>
<?php $component = $__componentOriginal4de142f7baa3ebde9816de5235a7814f; ?>
<?php unset($__componentOriginal4de142f7baa3ebde9816de5235a7814f); ?>
<?php endif; ?>


            <div class="container mx-auto p-6">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php
                        $mesageCount =  App\Models\Message::count();
                        $staffCount =  App\Models\User::where('user_type', \App\Enums\RoleEnum::Staff->value)->count();
                        $adminCount =  App\Models\User::where('user_type', \App\Enums\RoleEnum::Administrator->value)->count();
                        $superAdminCount =  App\Models\User::where('user_type', \App\Enums\RoleEnum::SuperAdministrator->value)->count();
                    ?>
                    <?php if (isset($component)) { $__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.count-card','data' => ['title' => 'Messages','count' => $mesageCount,'icon' => course_icon()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('count-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Messages'),'count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($mesageCount),'icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(course_icon())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d)): ?>
<?php $attributes = $__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d; ?>
<?php unset($__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d)): ?>
<?php $component = $__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d; ?>
<?php unset($__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.count-card','data' => ['title' => ucfirst(\App\Enums\RoleEnum::Staff->value),'count' => $staffCount,'icon' => user_icon()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('count-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(ucfirst(\App\Enums\RoleEnum::Staff->value)),'count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($staffCount),'icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(user_icon())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d)): ?>
<?php $attributes = $__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d; ?>
<?php unset($__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d)): ?>
<?php $component = $__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d; ?>
<?php unset($__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.count-card','data' => ['title' => ucfirst(\App\Enums\RoleEnum::Administrator->value),'count' => $adminCount,'icon' => admin_icon()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('count-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(ucfirst(\App\Enums\RoleEnum::Administrator->value)),'count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($adminCount),'icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(admin_icon())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d)): ?>
<?php $attributes = $__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d; ?>
<?php unset($__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d)): ?>
<?php $component = $__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d; ?>
<?php unset($__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d); ?>
<?php endif; ?>
                    <?php if(Auth::user()->user_type == \App\Enums\RoleEnum::SuperAdministrator->value): ?>
                        <?php if (isset($component)) { $__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.count-card','data' => ['title' => ucwords(\App\Enums\RoleEnum::SuperAdministrator->value),'count' => $superAdminCount,'icon' => super_admin_icon()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('count-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(ucwords(\App\Enums\RoleEnum::SuperAdministrator->value)),'count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($superAdminCount),'icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(super_admin_icon())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d)): ?>
<?php $attributes = $__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d; ?>
<?php unset($__attributesOriginalcadd9a6ee0a02fa127f8ada2625a087d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d)): ?>
<?php $component = $__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d; ?>
<?php unset($__componentOriginalcadd9a6ee0a02fa127f8ada2625a087d); ?>
<?php endif; ?>
                    <?php endif; ?>


                    <!-- Add more cards here if needed -->
                </div>

            </div>

        </div>
    </div>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\lara\congo-portfolio\resources\views/users/dashboard.blade.php ENDPATH**/ ?>