<h4 <?php echo e($attributes(['class' => 'text-md font-bold py-1 text-primary cursor-pointer  hover:text-xl w-full mt-4 mb-2 uppercase'])); ?>>
    <?php echo e($slot); ?>

</h4>
<?php /**PATH C:\lara\congo-portfolio\resources\views/components/page-location.blade.php ENDPATH**/ ?>